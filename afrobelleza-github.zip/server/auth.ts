import crypto from 'crypto';
import type { Request, Response, NextFunction } from 'express';

export const OWNER_NAME = 'AFROBELLEZA ADMIN';

const DEFAULT_CODE = 'afrobelleza2026';
const ADMIN_CODE = process.env.ADMIN_CODE || DEFAULT_CODE;
if (!process.env.ADMIN_CODE) {
  console.warn('⚠️  ADMIN_CODE pa defini. Ap itilize kòd default la. Mete yon ADMIN_CODE prive nan varyab anviwònman yo!');
}

const OWNER_TOKEN = crypto
  .createHmac('sha256', ADMIN_CODE)
  .update('afrobelleza-owner-v1')
  .digest('hex');

const sha = (s: string) => crypto.createHash('sha256').update(s).digest();

export function checkAdminCode(code: unknown): boolean {
  if (typeof code !== 'string' || !code) return false;
  return crypto.timingSafeEqual(sha(code), sha(ADMIN_CODE));
}

export function getOwnerToken(): string {
  return OWNER_TOKEN;
}

export function isOwnerRequest(req: Request): boolean {
  const h = String(req.headers.authorization || '');
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!token) return false;
  return crypto.timingSafeEqual(sha(token), sha(OWNER_TOKEN));
}

export function requireOwner(req: Request, res: Response, next: NextFunction) {
  if (isOwnerRequest(req)) return next();
  res.status(401).json({ success: false, message: 'Acceso restringido al propietario.' });
}

// Limit des tentatives de code admin (par IP)
const attempts = new Map<string, { count: number; resetAt: number }>();
export function adminAttemptAllowed(ip: string): boolean {
  const now = Date.now();
  const rec = attempts.get(ip);
  if (!rec || rec.resetAt < now) {
    attempts.set(ip, { count: 1, resetAt: now + 15 * 60 * 1000 });
    return true;
  }
  rec.count += 1;
  return rec.count <= 10;
}
