# AFROBELLEZA BARBER SHOP

Aplikasyon web pou salon an (React + Vite + Express). Rezèvasyon, mesaj, piblikasyon, galri, ak espas pwopriyetè.

## Lanse l lokalman
```
npm install
npm run dev
```
Louvri http://localhost:3000

## Pwopriyetè
Tape non `AFROBELLEZA ADMIN` epi kòd admin nan (varyab `ADMIN_CODE`, gade `.env.example`).

## Mete l sou entènèt
Gade [DEPLOY.md](DEPLOY.md) (Render, VPS, Docker). Aplikasyon an bezwen yon sèvè Node.js.
