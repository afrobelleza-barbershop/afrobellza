# AFROBELLEZA BARBER SHOP — Mete l sou entènèt (web)

Aplikasyon sa a gen yon sèvè Node.js (Express) ki kenbe done yo (rezèvasyon, mesaj, piblikasyon).
Se pou sa li pa ka mete sou yon sit estatik tankou GitHub Pages: li bezwen yon òtèl Node.js.

## ⚠️ KÒD ADMIN (obligatwa)
Pou antre kòm pwopriyetè, ou tape non **AFROBELLEZA ADMIN** epi yon **kòd admin**.
Kòd la se varyab `ADMIN_CODE`. Mete pwòp kòd prive pa w sou òtèl la (Render: Environment > ADMIN_CODE).
Si ou pa mete l, kòd default la se `afrobelleza2026` — chanje l imedyatman, paske tout moun ka li l nan dokimantasyon sa a.
Sèvè a refize tout aksyon pwopriyetè (chanje pri, efase, konfime rezèvasyon...) san kòd sa a.

## Opsyon 1 — Render.com (pi senp)
1. Mete tout fichye sa yo sou yon depo GitHub.
2. Sou Render: New > Blueprint (li li `render.yaml`) oswa New > Web Service.
3. Build: `npm install && npm run build` — Start: `npm start`
4. Ajoute yon "Disk" (mount `/var/data`) + varyab `DATA_DIR=/var/data` pou done yo pa disparèt.

## Opsyon 2 — VPS / sèvè pa w
```
npm install
npm run build
ADMIN_CODE=kod-ou npm start   # koute sou PORT (default 3000)
# Si dossier `dist` pa egziste, sèvè a bati l poukont li.
```
Mete Nginx devan (reverse proxy) pou domèn ou ak HTTPS.

## Opsyon 3 — Docker
```
docker build -t afrobelleza .
docker run -p 3000:3000 -v afro_data:/data -e DATA_DIR=/data afrobelleza
```

## Enpòtan
- Done yo estoke nan `data/afrobelleza_db.json` (oswa `DATA_DIR`). Fè backup regilye.
- Sou yon òtèl ki efase fichye a chak redeplwaman, itilize yon disk pèsistan.
