import React from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Ajoute automatiquement le jeton propriétaire aux appels /api
const originalFetch = window.fetch.bind(window);
window.fetch = (input: RequestInfo | URL, init?: RequestInit) => {
  try {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.pathname : input.url;
    if (url.startsWith('/api/')) {
      const token = localStorage.getItem('afrobelleza_token');
      if (token) {
        const headers = new Headers(init?.headers || (typeof input !== 'string' && !(input instanceof URL) ? input.headers : undefined));
        headers.set('Authorization', `Bearer ${token}`);
        return originalFetch(input, { ...init, headers });
      }
    }
  } catch {}
  return originalFetch(input, init);
};

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, background: '#0a0a0a', color: '#f5f5f5', fontFamily: 'sans-serif', textAlign: 'center' }}>
        <div>
          <h1 style={{ fontSize: 22, marginBottom: 8 }}>Algo salió mal</h1>
          <p style={{ opacity: 0.7, fontSize: 14, marginBottom: 16 }}>Ocurrió un error inesperado. Intenta recargar la aplicación.</p>
          <button onClick={() => { localStorage.removeItem('afrobelleza_token'); location.reload(); }} style={{ padding: '12px 24px', borderRadius: 12, background: '#f59e0b', color: '#0a0a0a', fontWeight: 800, border: 0, cursor: 'pointer' }}>Recargar</button>
        </div>
      </div>
    );
  }
}

createRoot(document.getElementById('root')!).render(<ErrorBoundary><App /></ErrorBoundary>);
